@echo off
title ExoRAG
color 0B

echo.
echo  ╔══════════════════════════════════════════════════════╗
echo  ║   ExoRAG — Starting App                             ║
echo  ╚══════════════════════════════════════════════════════╝
echo.

:: Check Docker is running
docker info >nul 2>&1
if errorlevel 1 (
    echo  ERROR: Docker is not running.
    echo  Please start Docker Desktop first, then run this again.
    pause
    exit /b 1
)

:: Check chroma_db has data
if not exist chroma_db\chroma.sqlite3 (
    echo  ERROR: Knowledge base not found.
    echo  Please run setup_first_time.bat first.
    pause
    exit /b 1
)

:: Start both services
echo  Starting Ollama + ExoRAG...
docker compose up -d

:: Wait a moment for services to initialize
echo  Waiting for app to start...
timeout /t 5 /nobreak >nul

:: Open browser
echo  Opening http://localhost:8501 ...
start http://localhost:8501

echo.
echo  ExoRAG is running at: http://localhost:8501
echo.
echo  ┌─────────────────────────────────────────────────────┐
echo  │  To stop the app:  run stop_app.bat                 │
echo  │  Or press Ctrl+C here then run: docker compose down │
echo  └─────────────────────────────────────────────────────┘
echo.

:: Follow logs so window stays open
docker compose logs -f exorag
