# ExoRAG — Docker Setup Guide

## Prerequisites — Docker Only

You only need **Docker Desktop** installed. No Python, no pip, nothing else.

- Download Docker Desktop: https://www.docker.com/products/docker-desktop/
- Start Docker Desktop (the whale icon in your taskbar)

---

## First Time Setup

### Windows
```
Double-click: setup_first_time.bat
```

### Mac / Linux
```bash
bash setup_first_time.sh
```

**What it does automatically:**
1. Checks Docker is installed and running
2. Opens `.env` for you to add your email + optional Claude API key
3. Builds the Docker image (Python + all dependencies + embedding model)
4. Starts Ollama and downloads llama3.2 (~2GB model)
5. Fetches 500+ PubMed abstracts
6. Builds the local ChromaDB vector index

**Total time: 30–45 minutes. Run once, never again.**

---

## Daily Usage

### Windows
```
Double-click: run_app.bat
```

### Mac / Linux
```bash
bash run_app.sh
```

Opens the app at: **http://localhost:8501**

### Stop the app
```
Windows: Double-click stop_app.bat
Mac/Linux: bash stop_app.sh
```

---

## File Structure

```
exorag/
├── Dockerfile              ← Python image definition
├── docker-compose.yml      ← ExoRAG + Ollama services
│
├── setup_first_time.bat    ← Windows: one-time setup
├── setup_first_time.sh     ← Mac/Linux: one-time setup
│
├── run_app.bat             ← Windows: daily launch
├── run_app.sh              ← Mac/Linux: daily launch
├── stop_app.bat / .sh      ← Stop everything
│
├── scripts/                ← Python scripts (inside container)
├── data/                   ← PubMed abstracts (persisted locally)
├── chroma_db/              ← Vector database (persisted locally)
├── outputs/                ← Logs and feedback (persisted locally)
└── .env                    ← Your API key (never committed)
```

**Key point:** `data/`, `chroma_db/`, and `outputs/` are mounted as volumes —
they live on your local machine, not inside the container.
This means your data survives container rebuilds.

---

## Updating PubMed Data

To refresh with new papers (run monthly):

```bash
# Windows
docker compose run --rm exorag python scripts/01_fetch_pubmed.py
docker compose run --rm exorag python scripts/02_build_index.py

# Mac/Linux
docker compose run --rm exorag python scripts/01_fetch_pubmed.py
docker compose run --rm exorag python scripts/02_build_index.py
```

---

## Troubleshooting

**"Docker is not running"**
→ Open Docker Desktop (the whale icon in taskbar/menu bar) and wait for it to start

**"port 8501 already in use"**
→ Run `stop_app.bat` / `bash stop_app.sh` first, then try again

**"port 11434 already in use"**
→ You have Ollama installed locally — stop it first:
   Windows: Task Manager → find Ollama → End Task
   Mac: `killall ollama`

**App opens but shows "No LLM found"**
→ Ollama container is still pulling the model. Wait 1-2 min and refresh.

**Slow first startup**
→ Normal — Ollama loads the model into memory (~1-2 min on 8GB RAM)

**Want to use Claude API instead of Ollama?**
→ Add `ANTHROPIC_API_KEY=sk-ant-...` to `.env`, restart with `run_app.bat`

**Delete everything and start fresh**
```bash
docker compose down -v          # removes containers + volumes
docker rmi exorag-exorag        # removes image
# then delete: data/ chroma_db/ outputs/
# then run setup_first_time again
```
