#!/bin/bash
echo ""
echo "Stopping ExoRAG..."
docker compose down
echo "All containers stopped."
echo "Your data (chroma_db, abstracts) is saved locally."
