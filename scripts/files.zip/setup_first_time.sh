#!/bin/bash
# ─────────────────────────────────────────────────────────────
# ExoRAG — First Time Setup (Mac / Linux)
# Run: bash setup_first_time.sh
# ─────────────────────────────────────────────────────────────

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   ExoRAG — First Time Setup (Mac / Linux)           ║"
echo "║   Exosome · Cosmetic · Natural Compound RAG         ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
echo "This will:"
echo "  1. Check Docker is installed"
echo "  2. Build the ExoRAG Docker image"
echo "  3. Start Ollama and pull llama3.2 model"
echo "  4. Fetch PubMed literature (~5-10 min)"
echo "  5. Build the ChromaDB vector index (~15-25 min)"
echo ""
echo "Total time: ~30-45 minutes on first run."
echo "You only need to run this ONCE."
echo ""
read -p "Press Enter to continue..."

# ── STEP 1: Check Docker ──────────────────────────────────────
echo ""
echo -e "${YELLOW}[1/5] Checking Docker...${NC}"

if ! command -v docker &>/dev/null; then
    echo -e "${RED}ERROR: Docker not found.${NC}"
    echo ""
    echo "Install Docker Desktop from:"
    echo "  Mac:   https://www.docker.com/products/docker-desktop/"
    echo "  Linux: https://docs.docker.com/engine/install/"
    exit 1
fi

echo "Found: $(docker --version)"

if ! docker info &>/dev/null; then
    echo -e "${RED}ERROR: Docker is installed but not running.${NC}"
    echo "Please start Docker Desktop and try again."
    exit 1
fi
echo -e "${GREEN}Docker is running. OK${NC}"

# ── STEP 2: Create .env ───────────────────────────────────────
echo ""
echo -e "${YELLOW}[2/5] Setting up configuration...${NC}"

mkdir -p data chroma_db outputs

if [ ! -f .env ]; then
    cp .env.example .env
    echo "Created .env from template."
    echo ""
    echo "┌─────────────────────────────────────────────────┐"
    echo "│  ACTION REQUIRED — Edit .env before continuing  │"
    echo "│                                                 │"
    echo "│  Set: ENTREZ_EMAIL=your.real@email.com          │"
    echo "│  Optional: ANTHROPIC_API_KEY=sk-ant-...         │"
    echo "└─────────────────────────────────────────────────┘"
    echo ""
    echo "Opening .env in your editor..."
    ${EDITOR:-nano} .env
    echo ""
    read -p "Press Enter after saving .env..."
else
    echo ".env already exists. OK"
fi

# ── STEP 3: Build Docker image ────────────────────────────────
echo ""
echo -e "${YELLOW}[3/5] Building ExoRAG Docker image...${NC}"
echo "(Downloads Python + dependencies + embedding model)"
echo "(First build: 10-20 min. Rebuilds are fast.)"
echo ""

docker compose build --no-cache
echo -e "${GREEN}Docker image built successfully.${NC}"

# ── STEP 4: Start Ollama + pull model ─────────────────────────
echo ""
echo -e "${YELLOW}[4/5] Starting Ollama and pulling llama3.2 model...${NC}"
echo "(Model download: ~2GB — takes 5-15 min)"
echo ""

docker compose up -d ollama

echo "Waiting for Ollama to be ready..."
until docker exec exorag_ollama ollama list &>/dev/null; do
    sleep 3
    echo "  Still waiting..."
done
echo -e "${GREEN}Ollama is ready.${NC}"

echo "Pulling llama3.2 model..."
docker exec exorag_ollama ollama pull llama3.2 || \
    docker exec exorag_ollama ollama pull llama3.2:1b
echo -e "${GREEN}Ollama model ready.${NC}"

# ── STEP 5: Fetch + Index ─────────────────────────────────────
echo ""
echo -e "${YELLOW}[5/5] Building knowledge base...${NC}"
echo ""

echo "Fetching PubMed abstracts (~5-10 min)..."
docker compose run --rm exorag python scripts/01_fetch_pubmed.py

echo ""
echo "Building ChromaDB vector index (~15-25 min)..."
docker compose run --rm exorag python scripts/02_build_index.py

# ── DONE ──────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   Setup Complete!                                   ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""
echo "To launch ExoRAG:"
echo "  bash run_app.sh"
echo "  Then open: http://localhost:8501"
echo ""
echo "You never need to run this setup again."
echo "(Unless you want to refresh the PubMed data)"
