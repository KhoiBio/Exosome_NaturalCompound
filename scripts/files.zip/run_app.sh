#!/bin/bash
# ─────────────────────────────────────────────────────────────
# ExoRAG — Launch App (Mac / Linux)
# Run: bash run_app.sh
# ─────────────────────────────────────────────────────────────

GREEN='\033[0;32m'; RED='\033[0;31m'; NC='\033[0m'

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   ExoRAG — Starting App                             ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# Check Docker running
if ! docker info &>/dev/null; then
    echo -e "${RED}ERROR: Docker is not running.${NC}"
    echo "Please start Docker Desktop first."
    exit 1
fi

# Check database exists
if [ ! -f "chroma_db/chroma.sqlite3" ]; then
    echo -e "${RED}ERROR: Knowledge base not found.${NC}"
    echo "Please run: bash setup_first_time.sh"
    exit 1
fi

# Start services
echo "Starting Ollama + ExoRAG..."
docker compose up -d

echo "Waiting for app to start..."
sleep 5

# Open browser
echo -e "${GREEN}Opening http://localhost:8501${NC}"
if [[ "$OSTYPE" == "darwin"* ]]; then
    open http://localhost:8501
else
    xdg-open http://localhost:8501 2>/dev/null || echo "Open http://localhost:8501 in your browser"
fi

echo ""
echo "ExoRAG is running at: http://localhost:8501"
echo "To stop: bash stop_app.sh"
echo ""

# Follow logs
docker compose logs -f exorag
