@echo off
setlocal EnableDelayedExpansion
title ExoRAG — First Time Setup
color 0A

echo.
echo  ╔══════════════════════════════════════════════════════╗
echo  ║   ExoRAG — First Time Setup                         ║
echo  ║   Exosome · Cosmetic · Natural Compound RAG         ║
echo  ╚══════════════════════════════════════════════════════╝
echo.
echo  This will:
echo    1. Check Docker is installed
echo    2. Build the ExoRAG Docker image
echo    3. Start Ollama and pull llama3.2 model
echo    4. Fetch PubMed literature (~5-10 min)
echo    5. Build the ChromaDB vector index (~15-25 min)
echo.
echo  Total time: ~30-45 minutes on first run.
echo  You only need to run this ONCE.
echo.
pause

:: ════════════════════════════════════════════════════════════
:: STEP 1 — Check Docker
:: ════════════════════════════════════════════════════════════

echo.
echo [1/5] Checking Docker...
docker --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  ERROR: Docker not found.
    echo.
    echo  Please install Docker Desktop from:
    echo  https://www.docker.com/products/docker-desktop/
    echo.
    echo  After installing, start Docker Desktop and run this
    echo  script again.
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('docker --version') do set DVER=%%v
echo  Found: %DVER%

:: Check Docker is running
docker info >nul 2>&1
if errorlevel 1 (
    echo.
    echo  ERROR: Docker is installed but not running.
    echo  Please start Docker Desktop and try again.
    echo.
    pause
    exit /b 1
)
echo  Docker is running. OK

:: ════════════════════════════════════════════════════════════
:: STEP 2 — Create .env if missing
:: ════════════════════════════════════════════════════════════

echo.
echo [2/5] Setting up configuration...

if not exist .env (
    copy .env.example .env >nul
    echo  Created .env from template.
    echo.
    echo  ┌─────────────────────────────────────────────────┐
    echo  │  ACTION REQUIRED — Edit .env before continuing  │
    echo  │                                                 │
    echo  │  Open .env in Notepad and set:                  │
    echo  │    ENTREZ_EMAIL=your.real@email.com             │
    echo  │                                                 │
    echo  │  Optional (for Claude API):                     │
    echo  │    ANTHROPIC_API_KEY=sk-ant-...                 │
    echo  │    Get key: https://console.anthropic.com       │
    echo  └─────────────────────────────────────────────────┘
    echo.
    notepad .env
    echo.
    echo  Press any key after saving your .env file...
    pause >nul
) else (
    echo  .env already exists. OK
)

:: Create local data directories (mounted into container)
if not exist data     mkdir data
if not exist chroma_db mkdir chroma_db
if not exist outputs  mkdir outputs

:: ════════════════════════════════════════════════════════════
:: STEP 3 — Build Docker image
:: ════════════════════════════════════════════════════════════

echo.
echo [3/5] Building ExoRAG Docker image...
echo  (Downloads Python + dependencies + embedding model)
echo  (First build: 10-20 min. Rebuilds are fast.)
echo.

docker compose build --no-cache
if errorlevel 1 (
    echo.
    echo  ERROR: Docker build failed.
    echo  Check the error above and try again.
    pause
    exit /b 1
)
echo  Docker image built successfully.

:: ════════════════════════════════════════════════════════════
:: STEP 4 — Start Ollama and pull model
:: ════════════════════════════════════════════════════════════

echo.
echo [4/5] Starting Ollama and pulling llama3.2 model...
echo  (Model download: ~2GB — takes 5-15 min depending on internet)
echo.

:: Start only Ollama first
docker compose up -d ollama
if errorlevel 1 (
    echo  ERROR: Could not start Ollama container.
    pause
    exit /b 1
)

:: Wait for Ollama to be ready
echo  Waiting for Ollama to start...
:wait_ollama
timeout /t 3 /nobreak >nul
docker exec exorag_ollama ollama list >nul 2>&1
if errorlevel 1 goto wait_ollama
echo  Ollama is ready.

:: Pull llama3.2 model
echo  Pulling llama3.2 model (this takes a few minutes)...
docker exec exorag_ollama ollama pull llama3.2
if errorlevel 1 (
    echo  WARNING: llama3.2 pull had issues. Trying smaller model...
    docker exec exorag_ollama ollama pull llama3.2:1b
)
echo  Ollama model ready.

:: ════════════════════════════════════════════════════════════
:: STEP 5 — Fetch PubMed + Build Index
:: ════════════════════════════════════════════════════════════

echo.
echo [5/5] Building knowledge base...
echo.

:: Start the exorag container in setup mode
docker compose run --rm exorag python scripts/01_fetch_pubmed.py
if errorlevel 1 (
    echo  ERROR: PubMed fetch failed. Check your ENTREZ_EMAIL in .env
    pause
    exit /b 1
)

echo.
echo  Building ChromaDB vector index (15-25 min)...
docker compose run --rm exorag python scripts/02_build_index.py
if errorlevel 1 (
    echo  ERROR: Index build failed.
    pause
    exit /b 1
)

:: ════════════════════════════════════════════════════════════
:: DONE
:: ════════════════════════════════════════════════════════════

echo.
echo  ╔══════════════════════════════════════════════════════╗
echo  ║   Setup Complete!                                   ║
echo  ╚══════════════════════════════════════════════════════╝
echo.
echo  To launch ExoRAG:
echo    Double-click run_app.bat
echo    Then open: http://localhost:8501
echo.
echo  You never need to run this setup again.
echo  (Unless you want to refresh the PubMed data)
echo.
pause
