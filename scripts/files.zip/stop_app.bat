@echo off
title ExoRAG — Stop
color 0C

echo.
echo  Stopping ExoRAG...
docker compose down
echo.
echo  All containers stopped.
echo  Your data (chroma_db, abstracts) is saved locally.
echo.
pause
